#!/usr/bin/env python3
"""Offline CLI for DIKWP IntentEconomy TransitionOS 2026 V1."""
from __future__ import annotations
import argparse, csv, json
from pathlib import Path
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parents[1]

def load_assets():
    rows=[]
    with open(ROOT/'data'/'content_asset_cases.csv',encoding='utf-8-sig') as f:
        for r in csv.DictReader(f):
            for k in ['D','I','K','W','P','R','attention_value','intent_value','risk']:
                r[k]=float(r[k])
            rows.append(r)
    return rows

def score(asset, mandate='compare', high_risk=False):
    intent_fit=(asset['P']+asset['W']+asset['R'])/3 + (8 if mandate!='recommend' else 0)
    evidence=(asset['D']+asset['I']+asset['K']+asset['R'])/4
    manipulation=asset['risk'] + (15 if high_risk else 0) - asset['W']/4 + asset['attention_value']/6
    transition=(intent_fit+evidence+asset['intent_value'])/3 - manipulation*0.22
    grade='INTENT-READY' if transition>=75 else 'CONDITIONAL' if transition>=55 else 'REPAIR-FIRST' if transition>=35 else 'BLOCK'
    return {'intent_fit':round(intent_fit,1),'evidence':round(evidence,1),'manipulation_risk':round(manipulation,1),'transition_readiness':round(transition,1),'grade':grade}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--asset-id',default='AE-003')
    p.add_argument('--mandate',default='compare')
    p.add_argument('--high-risk',action='store_true')
    p.add_argument('--out',type=Path,default=Path('outputs'))
    args=p.parse_args()
    assets=load_assets(); asset=next((a for a in assets if a['id']==args.asset_id),assets[0])
    report={'version':'DIKWP IntentEconomy TransitionOS 2026 V1 CLI','generated_at':datetime.now(timezone.utc).isoformat(),'asset':asset,'scorecard':score(asset,args.mandate,args.high_risk),'boundaries':{'no_real_user_tracking':True,'no_ad_network':True,'no_payment_or_trade_api':True,'human_review_required':True}}
    args.out.mkdir(parents=True,exist_ok=True)
    target=args.out/f"intent_transition_passport_{asset['id']}.json"
    target.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Output:',target)
    print(json.dumps(report['scorecard'],ensure_ascii=False,indent=2))
if __name__=='__main__': main()
