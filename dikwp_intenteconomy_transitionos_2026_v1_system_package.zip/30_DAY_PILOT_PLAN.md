# 30-Day Pilot Plan

## Week 1: Boundary and inventory
- select one low-risk content or service domain
- register stakeholders and prohibited intents
- create 20-50 Content DIKWP Cards

## Week 2: Intent contracts and projection
- create user-facing Intent Contract templates
- map content to 12 intent dimensions
- identify hidden sponsorship, privacy and autonomy risks

## Week 3: Agentic workflow sandbox
- implement agent mandate, offer proof and human gate
- test attention metrics against intent metrics
- generate Action Tickets for 3-No and purpose drift

## Week 4: Review and passport
- run governance review
- export Transition Passports
- decide continue, repair, restrict or stop

## Acceptance criteria
- no real user data
- no ad network or payment integration
- every intent has contract and kill conditions
- high-risk edges trigger human review
- outcome metrics include user autonomy and proof quality
