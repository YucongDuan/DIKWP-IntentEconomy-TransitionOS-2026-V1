# Governance and Safety Boundary

## Prohibited uses

- hidden behavioral targeting
- dark patterns or covert persuasive design
- unauthorized purchase or transaction execution
- sensitive targeting of vulnerable users
- political microtargeting or suppression
- health fear-based conversion
- collecting personal data without purpose, consent and minimization
- using latent intent inference as explicit user authorization

## Required controls

- Intent Contract before personalization
- Agent Mandate before tool use
- Offer Proof before recommendation ranking
- Human Gate before high-impact action
- Consent and revocation ledger
- Benefit-sharing and conflict-of-interest disclosure
- Residual and Kill Conditions for every high-risk edge

## Kill Conditions

Stop or downgrade the service if hidden sponsorship, purpose drift, vulnerable-user manipulation, privacy authorization gaps, evidence-free claims, or non-contestable automated action is detected.
