# Sources and Research Notes

- Harvard Data Science Review / MIT Press, “Beware the Intention Economy” (2024).
- McKinsey, “The agentic commerce opportunity” (2025).
- NIST AI Risk Management Framework and NIST Generative AI Profile.
- OECD AI Principles, updated 2024.
- EU AI Act, Regulation (EU) 2024/1689.
- DIKWP / Yucong Duan ecosystem materials: Evidence Ledger, Action Ticket, Human Review, and Static Boundary Audit design pattern.

All prototype scores are synthetic heuristic signals, not legal, commercial, compliance, accounting, or certification conclusions.
