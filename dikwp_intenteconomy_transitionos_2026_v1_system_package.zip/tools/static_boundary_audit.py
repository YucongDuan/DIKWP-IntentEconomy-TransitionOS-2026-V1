#!/usr/bin/env python3
"""Lightweight static boundary audit; not a security certification."""
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
PATTERNS=[(r"\bfetch\(","browser network fetch"),(r"XMLHttpRequest","XHR"),(r"\brequests\.","Python HTTP requests"),(r"urllib\.request","URL access"),(r"\bsocket\.","raw socket"),(r"\beval\(","dynamic eval"),(r"\bexec\(","dynamic exec"),(r"localStorage","browser local storage")]
EXCLUDE={'static_boundary_audit.py','static_boundary_audit_report.json'}
def main():
    findings=[]
    for p in ROOT.rglob('*'):
        if not p.is_file() or p.name in EXCLUDE or p.suffix.lower() not in {'.py','.html','.js','.json','.md'}: continue
        text=p.read_text(encoding='utf-8',errors='ignore')
        for pattern,meaning in PATTERNS:
            if re.search(pattern,text,re.I): findings.append({'file':str(p.relative_to(ROOT)),'meaning':meaning,'pattern':pattern})
    result={'package':'DIKWP IntentEconomy TransitionOS 2026 V1','network_or_high_risk_interface_detected':bool(findings),'findings':findings,'note':'No ad network, payment, brokerage, real user tracking, or production action adapters are included.'}
    (ROOT/'static_boundary_audit_report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
